<?php
// =========================================================================
// FILE        : InvoiceModel.php
// MODULE      : Module 4 — Internal Review & Approval Workflow
// SDD CLASS   : SDD_CLS_405 (Model Layer) — Invoice Entity
// DESCRIPTION : OOP Model class. Handles all raw database read/write
//               operations on the invoice and related tables.
//               No business logic here — only DB queries.
// =========================================================================

class InvoiceModel {
    private $db;

    public function __construct($dbConnection) {
        $this->db = $dbConnection;
    }

    // ── fetchPendingClaims() — SDD_CLS_401 officerMainDashboardUI ────────────
    // Returns all invoices, optionally filtered by status
    public function fetchPendingClaims($filterStatus = 'all') {
        if ($filterStatus !== 'all') {
            $safe = $this->db->real_escape_string($filterStatus);
            $sql = "SELECT i.invoice_ID, i.invoice_num, i.DO_ID, i.total,
                           i.invoice_status, i.invoice_date
                    FROM invoice i
                    WHERE i.invoice_status = '$safe'
                    ORDER BY i.invoice_ID DESC";
        } else {
            $sql = "SELECT i.invoice_ID, i.invoice_num, i.DO_ID, i.total,
                           i.invoice_status, i.invoice_date
                    FROM invoice i
                    ORDER BY i.invoice_ID DESC";
        }
        return $this->db->query($sql);
    }

    // ── Dashboard stat counts ─────────────────────────────────────────────────
    public function getDashboardStats() {
        return [
            'total'     => $this->db->query("SELECT COUNT(*) as c FROM invoice")->fetch_assoc()['c'],
            'submitted' => $this->db->query("SELECT COUNT(*) as c FROM invoice WHERE invoice_status='Submitted'")->fetch_assoc()['c'],
            'reviewing' => $this->db->query("SELECT COUNT(*) as c FROM invoice WHERE invoice_status='Under Review'")->fetch_assoc()['c'],
            'finance'   => $this->db->query("SELECT COUNT(*) as c FROM invoice WHERE invoice_status='Finance Review'")->fetch_assoc()['c'],
            'rejected'  => $this->db->query("SELECT COUNT(*) as c FROM invoice WHERE invoice_status='Rejected'")->fetch_assoc()['c'],
        ];
    }

    // ── getInvoiceById() — SDD_CLS_402 reviewSubmissionUI ────────────────────
    // Fetches full invoice + linked delivery order data
    public function getInvoiceById($invoiceId) {
        $stmt = $this->db->prepare(
            "SELECT i.*, d.supplier_ID, d.PO_ID, d.proof_of_delivery
             FROM invoice i
             INNER JOIN delivery_order d ON i.DO_ID = d.DO_ID
             WHERE i.invoice_ID = ? LIMIT 1"
        );
        $stmt->bind_param("i", $invoiceId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $result;
    }

    // ── updateStatus() — SDD_CLS_405 ReviewAndApprovalController ─────────────
    // Updates invoice_status in the database. Stores reason for Rejected only.
    public function updateStatus($invoiceId, $actionType, $remarks) {
        if ($actionType === 'Verified') {
            $stmt = $this->db->prepare(
                "UPDATE invoice SET invoice_status = 'Finance Review' WHERE invoice_ID = ?"
            );
            $stmt->bind_param("i", $invoiceId);
        } elseif ($actionType === 'UnderReview') {
            $stmt = $this->db->prepare(
                "UPDATE invoice SET invoice_status = 'Under Review' WHERE invoice_ID = ?"
            );
            $stmt->bind_param("i", $invoiceId);
        } else {
            $stmt = $this->db->prepare(
                "UPDATE invoice SET invoice_status = 'Rejected', reason = ? WHERE invoice_ID = ?"
            );
            $stmt->bind_param("si", $remarks, $invoiceId);
        }
        $success = $stmt->execute();
        $stmt->close();
        return $success;
    }

    // ── checkInvoiceStatus() — validate reviewable state ─────────────────────
    public function checkInvoiceStatus($invoiceId) {
        $stmt = $this->db->prepare(
            "SELECT invoice_status FROM invoice WHERE invoice_ID = ? LIMIT 1"
        );
        $stmt->bind_param("i", $invoiceId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $result;
    }

    // ── getInvoiceWithCustomer() — for notification sending ──────────────────
    public function getInvoiceWithCustomer($invoiceId) {
        $stmt = $this->db->prepare(
            "SELECT i.invoice_num, i.DO_ID, d.customer_ID
             FROM invoice i
             INNER JOIN delivery_order d ON i.DO_ID = d.DO_ID
             WHERE i.invoice_ID = ? LIMIT 1"
        );
        $stmt->bind_param("i", $invoiceId);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        return $result;
    }

    // ── insertNotification() — triggerNotifications() ────────────────────────
    public function insertNotification($customerId, $type, $content) {
        $stmt = $this->db->prepare(
            "INSERT INTO notification (customer_ID, type, content) VALUES (?, ?, ?)"
        );
        $stmt->bind_param("sss", $customerId, $type, $content);
        $stmt->execute();
        $stmt->close();
    }

    // ── fetchReportData() — SDD_CLS_404 generateReportUI ────────────────────
    // Retrieves filtered records for the management report
    public function fetchReportData($dateFrom, $dateTo, $status) {
        $whereParts = [];
        if (!empty($dateFrom)) $whereParts[] = "i.invoice_date >= '" . $this->db->real_escape_string($dateFrom) . " 00:00:00'";
        if (!empty($dateTo))   $whereParts[] = "i.invoice_date <= '" . $this->db->real_escape_string($dateTo)   . " 23:59:59'";
        if ($status !== 'all') $whereParts[] = "i.invoice_status = '" . $this->db->real_escape_string($status) . "'";
        $where = !empty($whereParts) ? 'WHERE ' . implode(' AND ', $whereParts) : '';

        $sql = "SELECT i.invoice_num, i.DO_ID, i.total, i.invoice_status, i.invoice_date,
                       s.supplier_name
                FROM invoice i
                INNER JOIN delivery_order d ON i.DO_ID = d.DO_ID
                INNER JOIN supplier s ON d.supplier_ID = s.supplier_ID
                $where
                ORDER BY i.invoice_date DESC";
        $result = $this->db->query($sql);
        $data = [];
        if ($result) {
            while ($row = $result->fetch_assoc()) $data[] = $row;
        }
        return $data;
    }
}
